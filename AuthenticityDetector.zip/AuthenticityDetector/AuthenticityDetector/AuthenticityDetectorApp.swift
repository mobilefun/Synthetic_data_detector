import SwiftUI

@main
struct AuthenticityDetectorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}